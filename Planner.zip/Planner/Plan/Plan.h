#pragma once

//8 semesters + up to 4 summer/winter semesters
//min 12 max 18 for school year, except for last semesters//max 8?? for summer
//semester - contains four courses


class Plan {
    
    private:
    
    
    
    
    
    
    
    
    
    
    public:
    
    
    
    
    
    
    
    
}